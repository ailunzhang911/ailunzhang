
const Wallet = () => {
  
  return (
    <div>
    </div>
  );
};

export default Wallet;